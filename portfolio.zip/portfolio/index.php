<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Professional Portfolio</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <h1>Portfolio.</h1>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Skills</a></li>
                <li><a href="#">Portfolio</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section class="hero">
            <div class="content">
                <h2>Hello, It's Me</h2>
                <h1>MD MEHRUB KHAN LIMON</h1>
                <h3>And I'm a <span>WEB-DEVELOPER </span></h3>
                <p>I am a dedicated web developer with expertise in PHP, HTML, and CSS, passionate about creating user-friendly and responsive web applications.</p>
                <div class="socials">
                    <a href="#"><img src="/portfolio/f.svg" alt="Facebook"></a>
                    <a href="#"><img src="/portfolio/t.png" alt="Twitter"></a>
                    <a href="#"><img src="/portfolio/i.webp" alt="Instagram"></a>
                    <a href="#"><img src="/portfolio/l.svg" alt="LinkedIn"></a>
                </div>
                <a href="#" class="btn">Download CV</a>
            </div>
            <div class="image">
                <img src="/portfolio/p.jpg" alt="John Kendric">
            </div>
        </section>
    </main>
</body>
</html>
